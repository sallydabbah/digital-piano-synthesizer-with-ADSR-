a=readmidi('jesu.mid',500);
